package com.classselector;

import net.minecraftforge.fml.common.Mod;

@Mod(ClassSelectorMod.MODID)
public class ClassSelectorMod {
    public static final String MODID = "classselector";
    /** Chave NBT (dados persistentes do jogador) com o id da classe escolhida. */
    public static final String KEY = "classselector_class";
    /** Chave NBT com o id da raça escolhida. */
    public static final String KEY_RACE = "classselector_race";

    public ClassSelectorMod() {
        Net.register();
        QuestNet.register();
    }
}
